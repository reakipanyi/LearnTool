# MAUI Android 安卓壳实施方案（优化版）

> 本方案基于原 `MAUI_Android_安卓壳实施方案.md` 进行深度优化，针对 **.NET MAUI** 框架特性、**ABP 模块化**架构及 **Android 平台**最佳实践，给出更落地、更细节、更安全的实施路径。重点优化：MAUI WebView 控件定制、JSBridge 双向通信机制、离线包热更新、性能与内存管理、安全加固及与现有系统无缝集成。

---

## 一、优化要点总览

| 原方案不足 | 优化措施 |
|---------|---------|
| 未明确 MAUI WebView 如何获取原生 Android WebView 进行深度定制 | 通过 `IWebViewHandler` 或 `Handler` 自定义，注入平台特定 `WebViewClient`、`WebChromeClient` |
| JSBridge 仅简单提及 `@JavascriptInterface`，缺少 MAUI 跨平台抽象 | 采用 **依赖注入 + 平台特定实现**，在 Android 端实现 `IJSBridge`，并通过 `WebView.AddJavascriptInterface` 注入 |
| 离线包更新流程未涉及断点续传、差量更新细节 | 设计 **Manifest + 差量包**，支持 MD5 校验、断点续传、原子切换与版本回滚 |
| 错误页和白屏检测未结合 MAUI 页面生命周期 | 使用 MAUI `ContentPage` 承载 WebView，错误页作为 `DataTemplate` 动态切换，避免 Activity 重建 |
| 内存管理未考虑 MAUI 跨平台 Handler 生命周期 | 通过 `WeakReference` 管理 WebView 引用，在 `OnDisappearing` 中主动释放 |
| 安全配置未说明如何集成 `network_security_config.xml` | 明确在 Android 项目 `Resources/xml` 中配置，并链接到 `AndroidManifest` |
| 监控日志未与现有 Serilog 管道打通 | 扩展 `Serilog` Sink，将壳日志写入同一管道，支持分级和上传 |
| 缺少 MAUI Shell 路由集成方式 | 注册 `WebViewShellPage` 到 Shell 路由，与现有页面共存 |

---

## 二、整体架构设计（优化版）

### 2.1 分层架构（结合 ABP）

```
┌─────────────────────────────────────────────────────────────┐
│  MAUI Shell (App.xaml.cs + Shell 路由)                     │
│  └─ WebViewShellPage.xaml (ContentPage)                    │
│      └─ WebView (MauiWebView)                              │
│          └─ Handler (AndroidWebViewHandler 扩展)           │
│              └─ 原生 Android.Webkit.WebView                │
│                 ├─ 注入 NativeBridge (JSBridge)            │
│                 ├─ 自定义 WebViewClient (错误处理、URL拦截) │
│                 └─ 自定义 WebChromeClient (进度、文件选择)  │
├─────────────────────────────────────────────────────────────┤
│  ABP 模块层 (WebViewShellModule)                           │
│   - 配置加载 (IWebViewConfig)                              │
│   - 服务注册 (IWebViewBridge, IOfflinePackageService...)   │
│   - 生命周期事件订阅                                       │
├─────────────────────────────────────────────────────────────┤
│  业务服务层 (Service)                                      │
│   - WebViewBridgeService (跨平台桥接分发)                  │
│   - OfflinePackageService (版本管理/下载/解压)             │
│   - WhiteScreenDetector (JS 注入检测)                     │
│   - ErrorPageHandler (错误页数据)                          │
│   - PerformanceMonitor (FPS、加载耗时)                     │
├─────────────────────────────────────────────────────────────┤
│  平台抽象层 (Contracts)                                    │
│   - IPlatformWebView (获取原生 WebView)                   │
│   - IJSBridge (平台桥接实现)                              │
│   - IFileChooser (文件选择回调)                           │
└─────────────────────────────────────────────────────────────┘
```

### 2.2 与现有系统的集成方式

- **模块注册**：`WebViewShellModule` 作为 ABP 模块，通过 `DependsOn(typeof(PosSaleCoreModule))` 依赖核心模块。
- **配置共享**：在 `appsettings.json` 中新增 `"WebViewShell"` 节点，通过 `IConfiguration` 注入。
- **服务注册**：所有壳服务注册为 `Scoped` 或 `Singleton`（根据生命周期），在 ViewModel 中可构造注入。
- **页面导航**：在 `AppShell.xaml` 中添加 `ShellContent` 路由，支持 `await Shell.GoToAsync("webview")`。

---

## 三、详细实施步骤（分阶段细化）

### 阶段一：基础壳 + 双模加载（1周）

#### 3.1.1 创建 WebViewShellPage

- 使用 MAUI 的 `WebView` 控件，通过 `x:Name` 访问。
- 在 XAML 中定义：
  ```xml
  <ContentPage xmlns="http://schemas.microsoft.com/dotnet/2021/maui"
               xmlns:x="http://schemas.microsoft.com/winfx/2009/xaml"
               x:Class="LenLe.PosSale.App.WebViewShell.Pages.WebViewShellPage">
      <Grid>
          <WebView x:Name="MainWebView"
                   Navigating="OnNavigating"
                   Navigated="OnNavigated"
                   HorizontalOptions="Fill" VerticalOptions="Fill" />
          <!-- 进度条 -->
          <ProgressBar x:Name="LoadingProgress" 
                       Progress="0" 
                       HeightRequest="3" 
                       VerticalOptions="Start"
                       IsVisible="False" />
          <!-- 错误页容器（覆盖层） -->
          <ContentView x:Name="ErrorContainer" IsVisible="False">
              <local:ErrorPage x:Name="ErrorPageControl" />
          </ContentView>
      </Grid>
  </ContentPage>
  ```

#### 3.1.2 获取原生 Android WebView 进行定制

在 `WebViewShellPage.xaml.cs` 中，利用 MAUI 的 `Handler` 获取平台原生控件：

```csharp
#if ANDROID
using Android.Webkit;

private AndroidWebViewClient _webViewClient;
private AndroidWebChromeClient _webChromeClient;

protected override void OnHandlerChanged()
{
    base.OnHandlerChanged();
    if (MainWebView.Handler?.PlatformView is Android.Webkit.WebView nativeWebView)
    {
        // 自定义 WebViewClient
        _webViewClient = new AndroidWebViewClient(this);
        nativeWebView.SetWebViewClient(_webViewClient);
        
        // 自定义 WebChromeClient
        _webChromeClient = new AndroidWebChromeClient(this);
        nativeWebView.SetWebChromeClient(_webChromeClient);
        
        // 注入 JSBridge
        var bridge = IPlatformApplication.Current?.Services.GetService<INativeBridge>();
        if (bridge != null)
        {
            nativeWebView.AddJavascriptInterface(bridge, "NativeBridge");
        }
        
        // 其他设置（启用 JS、硬件加速等）
        nativeWebView.Settings.JavaScriptEnabled = true;
        nativeWebView.Settings.LoadWithOverviewMode = true;
        nativeWebView.Settings.UseWideViewPort = true;
        nativeWebView.Settings.DomStorageEnabled = true;
    }
}
#endif
```

#### 3.1.3 双模加载实现

在 ViewModel 中根据配置决定加载源：

```csharp
public class WebViewShellViewModel : AbpViewModelBase
{
    private readonly IWebViewConfigService _configService;
    private readonly IOfflinePackageService _offlineService;

    public string CurrentUrl { get; private set; }

    public async Task InitializeAsync()
    {
        var config = await _configService.GetConfigAsync();
        if (config.Mode == LoadMode.Online)
        {
            CurrentUrl = config.OnlineUrl;
        }
        else
        {
            // 优先检查外部存储是否有离线包
            var localPath = await _offlineService.GetLocalPagePathAsync();
            if (!string.IsNullOrEmpty(localPath))
                CurrentUrl = "file://" + localPath;
            else
                CurrentUrl = "file:///android_asset/web/index.html"; // 内置备胎
        }
        await MainWebView.NavigateToAsync(CurrentUrl);
    }
}
```

#### 3.1.4 Android 返回键处理

在 `WebViewShellPage` 中重写 `OnBackButtonPressed`（MAUI 方式）或通过 Android 平台 `OnKeyDown`（平台特定），推荐使用 MAUI 的 `BackButtonPressed` 事件：

```csharp
protected override bool OnBackButtonPressed()
{
    if (MainWebView.CanGoBack)
    {
        MainWebView.GoBack();
        return true;
    }
    return base.OnBackButtonPressed(); // 可退出或返回上级
}
```

---

### 阶段二：JSBridge + 核心原生能力（1.5周）

#### 3.2.1 跨平台桥接抽象

在 `Contracts` 中定义：

```csharp
public interface INativeBridge
{
    // 供 JS 调用的方法，参数为 JSON 字符串
    [JavascriptInterface] // 仅 Android 需要，但接口保留
    string Call(string method, string jsonParams);
}

// Android 平台实现
public class AndroidNativeBridge : Java.Lang.Object, INativeBridge
{
    private readonly WeakReference<Activity> _activityRef;
    private readonly IJSBridgeHandler _handler; // 业务处理
    private readonly IMethodWhitelist _whitelist;
    
    [JavascriptInterface]
    public string Call(string method, string jsonParams)
    {
        // 1. 来源验证
        if (!_whitelist.IsDomainAllowed(CurrentUrl)) 
            return ErrorJson("domain_not_allowed");
        // 2. 方法白名单校验
        if (!_whitelist.IsMethodAllowed(method))
            return ErrorJson("method_not_allowed");
        // 3. 频率限制（滑动窗口）
        if (!RateLimiter.Allow(method))
            return ErrorJson("rate_limited");
        // 4. 执行
        return _handler.Execute(method, jsonParams);
    }
}
```

#### 3.2.2 H5 调用示例

```javascript
// JS 调用
NativeBridge.Call('getDeviceInfo', JSON.stringify({}), function(result) {
    console.log(result);
});
```

#### 3.2.3 核心能力实现列表（优化版）

针对 Android 平台，采用 **工厂模式** 按需注入：

| 能力 | Android 实现要点 | 权限需求 |
|-----|----------------|--------|
| 设备信息 | `Build.MODEL`, `Build.VERSION.RELEASE` 等 | 无 |
| GPS定位 | `FusedLocationProviderClient` + 动态权限 | `ACCESS_FINE_LOCATION` |
| 相机/相册 | `Intent.ACTION_IMAGE_CAPTURE` / `ACTION_PICK` + `ActivityResultLauncher` | `CAMERA`, `READ_EXTERNAL_STORAGE` |
| 剪贴板 | `ClipboardManager.SetPrimaryClip` | 无 |
| Toast | `Toast.MakeText` | 无 |
| 网络状态 | `ConnectivityManager` 主动获取 + 广播监听 | `ACCESS_NETWORK_STATE` |
| 下载管理 | `DownloadManager` 系统服务 | `WRITE_EXTERNAL_STORAGE` (Android < 11) |
| 系统分享 | `Intent.ACTION_SEND` | 无 |
| 振动 | `Vibrator.Vibrate` | `VIBRATE` |
| 屏幕方向 | `Activity.SetRequestedOrientation` | 无 |
| 全屏 | `Window.SetFlags` | 无 |
| 电量 | `BatteryManager` | 无 |

**所有权限均通过 `MauiPermissions` 或 `ActivityCompat` 动态申请，并提供友好引导。**

#### 3.2.4 安全加固（细粒度）

- **域名白名单**：在 `WebViewConfig` 中配置 `AllowedDomains`，每次调用时比对 `webView.Url`。
- **方法白名单**：使用特性标记，启动时通过反射生成列表。
- **调用频率限制**：基于内存缓存和滑动窗口（例如每分钟最多 30 次）。
- **敏感数据加密**：回调结果使用 AES-256-GCM 加密，密钥由 NDK 层提供（与 Java 层分离）。

---

### 阶段三：错误页 + 白屏检测 + 进度条（1周）

#### 3.3.1 进度条与加载超时

- 利用 `WebChromeClient.OnProgressChanged` 驱动 `ProgressBar`。
- 超时检测：使用 `Handler`（Android）或 `Task.Delay` 在 `OnPageStarted` 后启动，超时则显示重试按钮。

#### 3.3.2 错误页体系

实现 `IErrorPageHandler`，根据不同错误类型返回不同内容：

| 错误类型 | 检测方式 | 展示内容 |
|---------|---------|---------|
| 无网络 | `ConnectivityManager` 主动检测 + 网络变化广播 | 离线页 + 刷新按钮 |
| 加载超时 | `OnPageStarted` + 定时器 | 超时提示 + 重试 |
| SSL错误 | `OnReceivedSslError` | 安全警告（允许用户继续/退出） |
| HTTP错误 | `OnReceivedHttpError` | 错误码映射文案 |
| 渲染进程崩溃 | `OnRenderProcessGone` (API 26+) | 自动重建并恢复 |

所有错误页覆盖在 `ContentView` 中，可通过 `IsVisible` 切换，避免创建新 Activity。

#### 3.3.3 白屏检测与恢复

- 在 `OnPageFinished` 后延迟 2 秒注入 JS 获取 `document.body.innerText.length` 和可见元素数量。
- 若长度 < 50 或可见元素为 0，判定为白屏。
- 恢复策略：
  1. 尝试 `webView.Reload()`
  2. 若再次失败，加载本地备份页（如 assets 中的简易页）
  3. 记录日志并上报。

---

### 阶段四：性能优化 + 内存管理（1周）

#### 4.1 WebView 复用池（Android 专属）

采用 **对象池** 模式，在 `Application` 启动时预创建 1～2 个原生 WebView，使用时从池中取，关闭后回收（清空历史、重置设置）。MAUI 的 `WebView` 通过自定义 `Handler` 接管 `PlatformView` 的创建：

```csharp
public class PooledWebViewHandler : WebViewHandler
{
    protected override object CreatePlatformView()
    {
        return WebViewPool.Instance.Get(); // 从池中获取 Android.Webkit.WebView
    }
    protected override void DisconnectHandler(object platformView)
    {
        WebViewPool.Instance.Recycle(platformView as Android.Webkit.WebView);
        base.DisconnectHandler(platformView);
    }
}
```

注册 Handler：在 `MauiProgram.cs` 中 `ConfigureMauiHandlers`。

#### 4.2 首屏加速措施

- 预连接 DNS：`WebView.SetNetworkAvailable(true)` + `Preconnect` 预热。
- 静态资源拦截：在 `ShouldInterceptRequest` 中，将特定 CDN 资源替换为本地 assets 版本。
- 硬件加速：在 `AndroidManifest` 中为 Activity 开启 `android:hardwareAccelerated="true"`。
- 渲染优先级：`webView.SetRenderPriority(RenderPriority.High)`。

#### 4.3 内存泄漏彻底防范

- 使用 `WeakReference` 持有 Activity/Context，避免 JSBridge 间接持有。
- 在 Activity `OnDestroy` 或 MAUI Page `OnDisappearing` 中执行：
  ```csharp
  webView.StopLoading();
  webView.ClearHistory();
  webView.ClearCache(true);
  webView.ClearFormData();
  webView.LoadUrl("about:blank");
  webView.RemoveAllViews();
  webView.Destroy();
  ```
- 监听 `OnLowMemory` / `OnTrimMemory`，主动调用 `webView.FreeMemory()` 或回收池中闲置 WebView。

---

### 阶段五：离线包 + 热更新（1.5周）

#### 5.1 离线包结构（优化）

```
/data/data/包名/files/web/
├── version.json             # { version: "1.2.0", manifest: {...}, updateTime: "..."}
├── current/                 # 当前版本资源
│   ├── index.html
│   ├── static/
│   └── ...
├── backup/                  # 上一版本（回滚用）
└── download/                # 下载中临时目录（原子切换）
```

#### 5.2 更新流程细化

1. 应用启动时，后台（非阻塞）请求服务端 `/version` 接口，获取最新版本号。
2. 比较本地 `version.json`，若有更新：
   - WiFi 下自动下载；移动网络弹出确认框。
   - 下载采用 `HttpClient` + `Range` 头支持断点续传，同时计算 MD5。
   - 下载完成后解压到 `download/` 目录，验证 manifest（比对文件哈希）。
3. 若验证通过，将 `current/` 重命名为 `backup/`（覆盖旧备份），再将 `download/` 重命名为 `current/`（原子操作）。
4. 更新 `version.json`。
5. 若新版本加载失败（白屏、崩溃），触发回滚：将 `backup/` 恢复为 `current/`。

#### 5.3 加载优先级

```
1. 若存在外部存储 current/index.html → 加载 file://...
2. 否则加载 assets/web/index.html (内置基础版)
3. 若配置为在线模式，则加载远程 URL
```

---

### 阶段六：安全加固 + 监控集成（1周）

#### 6.1 Network Security Config

在 `Platforms/Android/Resources/xml/network_security_config.xml` 配置证书锁定：

```xml
<?xml version="1.0" encoding="utf-8"?>
<network-security-config>
    <domain-config>
        <domain includeSubdomains="true">api.yourdomain.com</domain>
        <pin-set expiration="2028-01-01">
            <pin digest="SHA-256">base64_encoded_public_key_hash</pin>
        </pin-set>
    </domain-config>
    <!-- 开发环境允许明文（仅 Debug） -->
    <debug-overrides>
        <trust-anchors>
            <certificates src="user" />
        </trust-anchors>
    </debug-overrides>
</network-security-config>
```

并在 `AndroidManifest.xml` 中引用：`android:networkSecurityConfig="@xml/network_security_config"`。

#### 6.2 WebView 其他安全配置

- `setAllowFileAccess(false)`（禁止 file 协议访问本地文件，除白名单外）
- `setAllowContentAccess(false)`
- `setAllowUniversalAccessFromFileURLs(false)`
- `setGeolocationEnabled(false)`（除非业务需要）

#### 6.3 混淆配置（ProGuard）

在 `LenLe.PosSale.App.csproj` 中添加：

```xml
<AndroidProguardConfiguration Include="proguard.cfg" />
```

`proguard.cfg` 内容：
```
-keep class com.lenle.nativebridge.** { *; }
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}
```

#### 6.4 监控集成（复用 Serilog）

- 在 `WebViewBridgeService` 中埋点，记录调用耗时、成功率。
- 使用 `Serilog` 的 `ILogger` 输出，并注册 `Sink` 将日志写入本地文件（按天滚动）和上报服务器。
- 集成 `Firebase.Crashlytics`（通过 NuGet `Xamarin.Firebase.Crashlytics`），捕获未处理异常。
- 性能监控：注入 JS 获取 FCP、LCP，通过 Bridge 上报。

---

### 阶段七：兼容性测试 + 厂商适配（1.5周）

#### 7.1 测试矩阵

| Android 版本 | 目标设备 | 重点测试项 |
|-------------|---------|----------|
| 5.0 - 6.0 | 低端机（2GB RAM） | 内存占用、WebView 稳定 |
| 7.0 - 8.0 | 主流中端 | 文件共享、SSL 证书锁定 |
| 9.0 - 11 | 高端机 | 分区存储、摄像头权限 |
| 12+ | 最新设备 | 隐私权限、剪贴板适配 |

#### 7.2 厂商特定适配

- **华为**：推送集成 HMS Push，注意 WebView 内核版本（华为 EMUI 内置 Chrome）。
- **小米**：MIUI 后台限制需申请 `WAKE_LOCK` 保持下载。
- **OPPO/VIVO**：文件选择需适配 ColorOS / FuntouchOS 的 Intent 行为差异。
- **刘海屏/挖孔屏**：通过 `WindowInsets` 获取显示区域，调整 WebView 布局。

---

## 四、与现有 ABP 模块集成细节

### 4.1 模块定义

```csharp
[DependsOn(typeof(PosSaleCoreModule))]
public class WebViewShellModule : AbpModule
{
    public override void PreConfigureServices(ServiceConfigurationContext context)
    {
        // 加载配置
        var configuration = context.Services.GetConfiguration();
        context.Services.Configure<WebViewConfig>(configuration.GetSection("WebViewShell"));
    }

    public override void ConfigureServices(ServiceConfigurationContext context)
    {
        // 注册服务
        context.Services.AddTransient<IWebViewConfigService, WebViewConfigService>();
        context.Services.AddSingleton<IOfflinePackageService, OfflinePackageService>();
        context.Services.AddScoped<IJSBridgeHandler, JSBridgeHandler>();
        // 平台特定服务在 Android 启动时额外注册（通过条件注入）
    }

    public override void OnApplicationInitialization(ApplicationInitializationContext context)
    {
        // 启动后台更新检查
        var offlineService = context.ServiceProvider.GetRequiredService<IOfflinePackageService>();
        offlineService.CheckUpdateAsync().ConfigureAwait(false);
    }
}
```

### 4.2 配置示例（appsettings.json）

```json
{
  "WebViewShell": {
    "Mode": "Local",  // Online / Local
    "OnlineUrl": "https://m.yourdomain.com",
    "AllowedDomains": ["yourdomain.com", "cdn.yourdomain.com"],
    "OfflinePackage": {
      "BaseUrl": "https://cdn.yourdomain.com/packages",
      "VersionFile": "version.json",
      "LocalPath": "web"
    },
    "TimeoutSeconds": 15,
    "EnableWhiteScreenDetection": true,
    "EnablePerformanceMonitor": true
  }
}
```

---

## 五、风险应对与测试策略

| 风险 | 应对措施 |
|-----|---------|
| 系统 WebView 版本过低（< 5.0） | 检测 `WebView.getCurrentWebViewPackage()`，若版本低于 55，引导用户升级或集成腾讯 X5（备选） |
| 离线包下载中断 | 使用断点续传，支持重试，失败后保留旧版本 |
| 内存泄露导致 OOM | 严格销毁 + LeakCanary（Debug）检测，Release 使用 Firebase 监控 |
| 厂商定制导致 Bridge 调用失败 | 真机测试覆盖主流机型，增加容错（返回默认值） |
| HTTPS 证书过期 | 在证书固定中设置宽松窗口，并提供动态更新机制 |

---

## 六、开发与测试时间线（优化后）

| 阶段 | 内容 | 周期 | 产出 |
|-----|-----|-----|-----|
| 一 | 基础壳+双模加载 | 1 周 | 可运行的 WebView 页面，支持切换模式 |
| 二 | JSBridge+核心能力 | 1.5 周 | 25+ 原生能力，含安全加固 |
| 三 | 错误页+白屏检测+进度条 | 1 周 | 完整兜底 UI 和自动恢复 |
| 四 | 性能优化+内存管理 | 1 周 | WebView 池、内存监控、首屏提速 |
| 五 | 离线包+热更新 | 1.5 周 | 版本管理、下载、原子切换、回滚 |
| 六 | 安全加固+监控集成 | 1 周 | 证书锁定、混淆、日志与崩溃上报 |
| 七 | 兼容性测试+厂商适配 | 1.5 周 | 主流机型测试报告、修复 |
| **总计** | | **8.5 周** | |

---

## 七、总结

本优化方案充分结合了 **.NET MAUI** 框架特性和 **ABP** 模块化设计，将 WebView 壳作为独立模块无缝嵌入现有 `LenLe.PosSale` 应用。通过平台抽象、细粒度安全策略、性能优化、离线包机制及完整监控体系，确保达到 **商用级 Android 壳** 的标准。实施过程中可根据实际需求灵活裁剪（如不需要推送、支付等可选能力），也可与现有原生页面混合导航，实现平滑过渡。

> 所有代码示例均为示意，实际开发需根据项目命名空间和依赖版本调整。建议采用 TDD 方式，每个阶段伴随单元测试和真机验证。


要高质量地完成这个“MAUI Android 安卓壳”方案，核心在于跨越 **.NET MAUI 框架、Android 原生开发、前端与原生通信、性能与安全**等多个技术领域。

下表梳理了实施过程中所需的关键技能，并按重要性和应用阶段进行了排序，可以作为你搭建团队或自我提升的参考：

| 技能领域 | 核心技能点 | 关键程度 | 主要应用阶段 |
| :--- | :--- | :--- | :--- |
| **🚀 .NET MAUI 核心开发** | MAUI 应用生命周期、MVVM 模式、依赖注入、自定义渲染器/处理程序(Handler) | ★★★★★ | 阶段一、四、六 |
| **🤖 Android 平台深度定制** | Android `WebView`、`WebViewClient`/`WebChromeClient` 定制、`@JavascriptInterface` 桥接 | ★★★★★ | 阶段一、二、三 |
| **🌉 JSBridge 双向通信** | 原生与 JavaScript 互调、`EvaluateJavaScriptAsync`、回调机制、`HybridWebView` | ★★★★★ | 阶段二 |
| **⚡️ 性能优化与内存管理** | WebView 内存泄漏排查与解决、对象池、资源加载优化、Android Profiler 使用 | ★★★★★ | 阶段四 |
| **🔐 安全加固** | 证书锁定(Certificate Pinning)、`network_security_config`、HTTPS 强制、混淆与反编译对抗 | ★★★★★ | 阶段六 |
| **📦 离线包与热更新** | ZIP 解压、文件 I/O、MD5 校验、版本管理与回滚、后台下载 | ★★★★☆ | 阶段五 |
| **📊 监控与日志体系** | 性能埋点(FCP/LCP)、崩溃上报(Crashlytics/Bugly)、日志分级与上传 | ★★★★☆ | 阶段六 |
| **🧪 测试与调试** | 多机型/多版本兼容性测试、Android 调试工具(ADB)、UI 自动化测试 | ★★★★☆ | 阶段七 |

---

### 🚀 .NET MAUI 核心开发

这是整个项目的根基，你需要熟练掌握 MAUI 的开发模式。

*   **自定义 Handler**：方案中大量定制工作（如自定义 `WebViewClient`）都需通过自定义 Handler 实现。你需要理解如何通过 `Mapper` 来修改或扩展 MAUI 控件的底层行为。
*   **生命周期与 MVVM**：需要正确处理页面(`ContentPage`)的生命周期事件，并与 MVVM 模式结合，将 WebView 的状态（如加载地址、进度）通过数据绑定进行管理。
*   **依赖注入**：利用 MAUI 的容器（结合 ABP 的 Autofac）来注册和管理 `IWebViewConfigService`、`IOfflinePackageService` 等服务。

---

### 🤖 Android 平台深度定制

这部分是实现“安卓壳”特性的技术核心。

*   **原生 WebView 控制**：必须能通过 MAUI 的 Handler 获取到原生的 `Android.Webkit.WebView` 对象。
*   **定制 WebViewClient**：通过继承 `MauiWebViewClient` 或 `WebViewClient` 来重写关键方法：
    *   `OnPageStarted` / `OnPageFinished`：用于实现进度条、超时检测和白屏检测的触发点。
    *   `ShouldOverrideUrlLoading`：用于拦截 URL 加载，是实现 URL 白名单安全策略的关键。
    *   `OnReceivedSslError`：用于处理 SSL 错误，是证书锁定逻辑的一部分。
    *   `OnRenderProcessGone`：用于处理 WebView 渲染进程崩溃，实现自动恢复。
*   **定制 WebChromeClient**：通过继承 `MauiWebChromeClient` 来处理网页相关的 UI 事件。
    *   `OnProgressChanged`：用于驱动顶部进度条。
    *   `OnPermissionRequest`：用于处理网页发起的权限请求（如地理位置、相机等）。

---

### 🌉 JSBridge 双向通信

这是连接原生与 H5 页面的“桥梁”，决定了壳的扩展能力。

*   **原生调用 JavaScript**：使用 MAUI `WebView` 的 `EvaluateJavaScriptAsync` 方法，这是双向通信的基础。
*   **JavaScript 调用原生**：
    *   **核心机制**：在 Android 端，通过 `webView.AddJavascriptInterface` 注入一个继承自 `Java.Lang.Object` 的 C# 类实例。
    *   **关键注解**：被 JavaScript 调用的 C# 方法必须使用 `[JavascriptInterface]` 注解。
*   **HybridWebView**：MAUI 提供了 `HybridWebView` 控件，它封装了双向通信的复杂性，是另一种实现 JSBridge 的选择。

---

### ⚡️ 性能优化与内存管理

WebView 是内存大户，这部分技能直接关系到应用的稳定性。

*   **内存泄漏防治**：
    *   在 Activity 或 Fragment 销毁时，严格执行清理流程：`webView.stopLoading()`、`webView.clearHistory()`、`webView.clearCache(true)`，最后调用 `webView.destroy()`。
    *   避免使用静态内部类或匿名内部类持有 WebView 引用，应使用 `WeakReference`。
*   **性能分析工具**：熟练使用 **Android Studio 的 Profiler** 和 **Visual Studio 的诊断工具**来监控内存、CPU 和网络活动。
*   **资源优化**：启用硬件加速、设置合理的缓存策略、预创建 WebView 实例池等。

---

### 🔐 安全加固

确保 WebView 壳能够安全地在生产环境运行。

*   **网络安全配置**：通过 `network_security_config.xml` 文件实现 **证书锁定（Certificate Pinning）**，这是防范中间人攻击的最有效手段。
*   **WebView 安全设置**：必须禁用 `setAllowFileAccess`、`setAllowContentAccess` 等高风险设置，并根据需要管理 JavaScript 执行和 Geolocation 权限。
*   **代码混淆**：配置 ProGuard 或 R8，确保 `[JavascriptInterface]` 标注的方法不会被混淆，从而保证 JS 能正常调用。

---

### 📦 离线包与热更新

这部分更多是通用工程能力的体现。

*   **文件与网络操作**：需要实现 ZIP 包的下载（支持断点续传）、解压、MD5 校验以及文件的原子性替换操作。
*   **版本管理**：设计并解析 `version.json` 等清单文件，实现版本的比较、更新和回滚逻辑。

---

### 🧪 测试与调试

全面的测试是保障质量、减少返工的关键。

*   **兼容性测试**：方案需要在 Android 5.0 (API 21) 到 Android 12+ (API 31+) 的众多版本上验证，尤其要关注各厂商（华为、小米、OPPO、VIVO）的定制系统。
*   **调试工具**：熟练使用 `adb logcat` 查看日志，利用 Chrome 的 `chrome://inspect` 调试 WebView 内的 H5 页面。

---

**总结**：这个项目要求开发者既是“Android 系统工程师”（能深入定制 WebView），又是“.NET MAUI 架构师”（能设计跨平台模块），同时还具备“安全与性能专家”的视野。建议在项目启动前，对团队进行针对性的技术预研和培训，尤其是在 **自定义 Handler** 和 **JSBridge 实现**这两个核心难点上，可以有效规避后期的技术风险。

 